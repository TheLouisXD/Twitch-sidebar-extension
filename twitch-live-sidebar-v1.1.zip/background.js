(function() {
	//#region src/config.js
	var CLIENT_ID = "7wvduf9b5669znfl36ey3oraencfv8";
	var SCOPES = "user:read:follows";
	var WORKER_URL = "https://twitch-auth-worker.thelouisxd.workers.dev";
	var API_URL = "https://api.twitch.tv/helix";
	//#endregion
	//#region src/platform.js
	function createPlatform(scope = globalThis) {
		const usesPromises = Boolean(scope.browser?.runtime?.id);
		const api = usesPromises ? scope.browser : scope.chrome;
		function call(path, ...args) {
			const parts = path.split(".");
			const method = parts.pop();
			const owner = parts.reduce((value, key) => value?.[key], api);
			if (typeof owner?.[method] !== "function") return Promise.reject(/* @__PURE__ */ new Error(`Extension API unavailable: ${path}`));
			if (usesPromises || path.startsWith("sidePanel.") || path === "alarms.create") try {
				return Promise.resolve(owner[method](...args));
			} catch (error) {
				return Promise.reject(error);
			}
			return new Promise((resolve, reject) => {
				owner[method](...args, (result) => {
					const error = api.runtime.lastError;
					if (error) reject(new Error(error.message));
					else resolve(result);
				});
			});
		}
		return {
			api,
			call,
			isFirefox: Boolean(api?.sidebarAction)
		};
	}
	var { api: extension, call: callExtension, isFirefox } = createPlatform();
	var localGet = (keys) => callExtension("storage.local.get", keys);
	var localSet = (values) => callExtension("storage.local.set", values);
	var localRemove = (keys) => callExtension("storage.local.remove", keys);
	var sessionGet = (keys) => callExtension("storage.session.get", keys);
	var sessionSet = (values) => callExtension("storage.session.set", values);
	var sessionRemove = (keys) => callExtension("storage.session.remove", keys);
	//#endregion
	//#region src/auth.js
	var AuthError = class extends Error {};
	async function requestTokens(endpoint, body) {
		const response = await fetch(`${WORKER_URL}/${endpoint}`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(body),
			signal: AbortSignal.timeout(3e4)
		});
		const data = await response.json();
		if (!response.ok || data.error) {
			const message = data.error || "Token request failed";
			if (response.status === 400 || response.status === 401) throw new AuthError(message);
			throw new Error(message);
		}
		if (typeof data.access_token !== "string" || !data.access_token || typeof data.refresh_token !== "string" || !data.refresh_token) throw new Error("Invalid token response");
		return data;
	}
	async function revokeToken(token) {
		if (!token) return;
		try {
			await fetch(`${WORKER_URL}/revoke`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ token }),
				signal: AbortSignal.timeout(1e4)
			});
		} catch (error) {
			console.error("Token revocation failed:", error);
		}
	}
	//#endregion
	//#region src/preferences.js
	var POLL_INTERVAL_KEY = "pollIntervalMinutes";
	var FAVORITES_FIRST_KEY = "favoritesFirst";
	var REMEMBER_SESSION_KEY = "rememberSession";
	var THEME_KEY = "theme";
	var DEFAULT_THEME = "default";
	var POLL_INTERVAL_OPTIONS = [
		1,
		2,
		3,
		5,
		10,
		15,
		30,
		60
	];
	var THEME_OPTIONS = ["default", "gx"];
	function normalizePollInterval(value) {
		return POLL_INTERVAL_OPTIONS.includes(value) ? value : 3;
	}
	function normalizeTheme(value) {
		return THEME_OPTIONS.includes(value) ? value : DEFAULT_THEME;
	}
	/** @returns {Promise<import("./types.js").Preferences>} */
	async function getPreferences() {
		const preferences = await localGet([
			POLL_INTERVAL_KEY,
			FAVORITES_FIRST_KEY,
			REMEMBER_SESSION_KEY,
			THEME_KEY
		]);
		return {
			pollIntervalMinutes: normalizePollInterval(preferences[POLL_INTERVAL_KEY]),
			favoritesFirst: preferences[FAVORITES_FIRST_KEY] === true,
			rememberSession: preferences[REMEMBER_SESSION_KEY] !== false,
			theme: normalizeTheme(preferences[THEME_KEY])
		};
	}
	//#endregion
	//#region src/cache.js
	var CHANNELS_KEY = "twitch_channels_cache";
	var PROFILES_KEY = "twitch_profiles_cache";
	var USER_PROFILE_KEY = "twitch_user_profile_cache";
	var NOTIFICATIONS_KEY = "notification_streamers";
	var PREV_LIVE_KEY = "previously_live";
	var TWENTY_FOUR_HOURS = 864e5;
	function isFresh(timestamp, maxAge) {
		const age = Date.now() - timestamp;
		return Number.isFinite(timestamp) && age >= 0 && age < maxAge;
	}
	async function getCachedChannels() {
		const { [CHANNELS_KEY]: entry, [POLL_INTERVAL_KEY]: interval } = await localGet([CHANNELS_KEY, POLL_INTERVAL_KEY]);
		if (!decodeChannelCache(entry)) return null;
		return {
			data: entry.data,
			ts: entry.ts,
			fresh: isFresh(entry.ts, normalizePollInterval(interval) * 60 * 1e3)
		};
	}
	function decodeChannelCache(entry) {
		return Array.isArray(entry?.data?.live) && Array.isArray(entry?.data?.offline) ? entry : null;
	}
	function setCachedChannels(data) {
		return localSet({ [CHANNELS_KEY]: {
			data,
			ts: Date.now()
		} });
	}
	async function getCachedProfiles() {
		const { [PROFILES_KEY]: entry } = await localGet(PROFILES_KEY);
		return {
			map: entry?.map ?? {},
			fresh: isFresh(entry?.ts, TWENTY_FOUR_HOURS)
		};
	}
	function setCachedProfiles(map) {
		return localSet({ [PROFILES_KEY]: {
			map,
			ts: Date.now()
		} });
	}
	async function getCachedUserProfile() {
		const { [USER_PROFILE_KEY]: entry } = await localGet(USER_PROFILE_KEY);
		if (!entry?.profile) return null;
		return {
			profile: entry.profile,
			fresh: isFresh(entry.ts, TWENTY_FOUR_HOURS)
		};
	}
	function setCachedUserProfile(profile) {
		return localSet({ [USER_PROFILE_KEY]: {
			profile,
			ts: Date.now()
		} });
	}
	function clearAllCache() {
		return localRemove([
			CHANNELS_KEY,
			PROFILES_KEY,
			USER_PROFILE_KEY,
			NOTIFICATIONS_KEY,
			PREV_LIVE_KEY
		]);
	}
	//#endregion
	//#region src/session.js
	var revision = 0;
	var refreshTask;
	var restoreTask;
	var tokenWrites = /* @__PURE__ */ new Set();
	var credentialQueue = Promise.resolve();
	var getSessionRevision = () => revision;
	var invalidateSession = () => {
		revision++;
	};
	var SessionChangedError = class extends Error {
		code = "SESSION_CHANGED";
	};
	function assertSession(expected) {
		if (revision !== expected) throw new SessionChangedError("Session changed");
	}
	async function guardSession(expected, operation) {
		try {
			assertSession(expected);
			const result = await operation();
			assertSession(expected);
			return result;
		} catch (error) {
			assertSession(expected);
			if (error instanceof AuthError) error.sessionRevision = expected;
			throw error;
		}
	}
	function queueCredentials(expected, operation) {
		const task = credentialQueue.then(() => guardSession(expected, operation));
		credentialQueue = task.catch(() => {});
		tokenWrites.add(task);
		return task.finally(() => {
			tokenWrites.delete(task);
		});
	}
	function saveTokens(tokens, expected = revision) {
		return queueCredentials(expected, async () => {
			assertSession(expected);
			if ((await localGet("rememberSession"))["rememberSession"] !== false) {
				await localSet({ twitch_refresh_token: tokens.refresh_token });
				await sessionRemove("twitch_refresh_token");
			} else {
				await sessionSet({ twitch_refresh_token: tokens.refresh_token });
				await localRemove("twitch_refresh_token");
			}
			assertSession(expected);
			await sessionSet({
				twitch_access_token: tokens.access_token,
				twitch_validated_at: 0
			});
			assertSession(expected);
			return tokens.access_token;
		});
	}
	function setRememberSession(enabled) {
		const expected = revision;
		return queueCredentials(expected, async () => {
			const [local, session] = await Promise.all([localGet([REMEMBER_SESSION_KEY, "twitch_refresh_token"]), sessionGet("twitch_refresh_token")]);
			assertSession(expected);
			const previous = local[REMEMBER_SESSION_KEY] !== false;
			const token = previous ? local.twitch_refresh_token : session.twitch_refresh_token;
			const copyTo = async (persistent) => {
				if (token) await (persistent ? localSet : sessionSet)({ twitch_refresh_token: token });
			};
			const removeOther = (persistent) => (persistent ? sessionRemove : localRemove)("twitch_refresh_token");
			try {
				await copyTo(enabled);
				await localSet({ [REMEMBER_SESSION_KEY]: enabled });
				await removeOther(enabled);
			} catch (error) {
				await copyTo(previous);
				await localSet({ [REMEMBER_SESSION_KEY]: previous });
				await removeOther(previous);
				throw error;
			}
			return { rememberSession: enabled };
		});
	}
	function getRefreshToken(expected) {
		return queueCredentials(expected, async () => {
			return ((await localGet("rememberSession"))["rememberSession"] !== false ? await localGet("twitch_refresh_token") : await sessionGet("twitch_refresh_token")).twitch_refresh_token;
		});
	}
	async function revokeSessionTokens() {
		try {
			const [sessionCreds, localCreds] = await Promise.all([sessionGet(["twitch_access_token", "twitch_refresh_token"]), localGet("twitch_refresh_token")]);
			const token = sessionCreds.twitch_access_token || sessionCreds.twitch_refresh_token || localCreds.twitch_refresh_token;
			if (token) await revokeToken(token);
		} catch (error) {
			console.error("Token revocation failed:", error);
		}
	}
	async function clearTokens() {
		await sessionRemove([
			"twitch_access_token",
			"twitch_validated_at",
			"twitch_refresh_token"
		]);
		await localRemove("twitch_refresh_token");
	}
	function refreshSession() {
		if (refreshTask) return refreshTask;
		const expected = revision;
		refreshTask = guardSession(expected, async () => {
			const token = await getRefreshToken(expected);
			assertSession(expected);
			if (!token) throw new AuthError("Sign in required");
			return saveTokens(await requestTokens("refresh", { refresh_token: token }), expected);
		}).finally(() => {
			refreshTask = null;
		});
		return refreshTask;
	}
	function restoreSession() {
		if (restoreTask) return restoreTask;
		const expected = revision;
		restoreTask = guardSession(expected, async () => {
			const { twitch_access_token: token, twitch_validated_at: validatedAt } = await sessionGet(["twitch_access_token", "twitch_validated_at"]);
			assertSession(expected);
			const age = Date.now() - validatedAt;
			if (token && age >= 0 && age < 36e5) return token;
			if (token) {
				const response = await fetch("https://id.twitch.tv/oauth2/validate", {
					headers: { Authorization: `OAuth ${token}` },
					signal: AbortSignal.timeout(3e4)
				});
				assertSession(expected);
				if (response.ok) {
					const data = await response.json();
					if (data.client_id !== "7wvduf9b5669znfl36ey3oraencfv8" || !"user:read:follows".split(" ").every((scope) => data.scopes?.includes(scope))) throw new AuthError("Twitch authorization must be renewed");
					assertSession(expected);
					await sessionSet({ twitch_validated_at: Date.now() });
					return token;
				}
				if (response.status !== 401) throw new Error(`Token validation failed: ${response.status}`);
			}
			const refreshToken = await getRefreshToken(expected);
			assertSession(expected);
			if (token && !refreshToken) throw new AuthError("Sign in required");
			return refreshToken ? refreshSession() : null;
		}).finally(() => {
			restoreTask = null;
		});
		return restoreTask;
	}
	async function withSession(operation) {
		const expected = revision;
		return guardSession(expected, async () => {
			let token = await restoreSession();
			assertSession(expected);
			if (!token) throw new AuthError("Sign in required");
			try {
				return await operation(token);
			} catch (error) {
				assertSession(expected);
				if (!(error instanceof AuthError)) throw error;
				token = await refreshSession();
				assertSession(expected);
				return operation(token);
			}
		});
	}
	function waitForSessionTasks() {
		return Promise.allSettled([
			refreshTask,
			restoreTask,
			...tokenWrites
		].filter(Boolean));
	}
	//#endregion
	//#region src/twitch.js
	async function fetchTwitch(token, path, params = new URLSearchParams()) {
		const response = await fetch(`${API_URL}/${path}?${params}`, {
			headers: {
				"Client-ID": CLIENT_ID,
				Authorization: `Bearer ${token}`
			},
			signal: AbortSignal.timeout(3e4)
		});
		if (response.status === 401) throw new AuthError("Token expired");
		if (!response.ok) throw new Error(`Twitch API error: ${response.status}`);
		const result = await response.json();
		if (!Array.isArray(result.data)) throw new Error("Invalid Twitch response");
		return result;
	}
	/**
	* Reduces avatar image resolution from 300x300 to 150x150 for faster network transfer.
	* Preserves the original URL if not matching the standard pattern.
	* @param {string|null} url
	* @param {string} [size="150x150"]
	* @returns {string|null}
	*/
	function formatAvatarUrl(url, size = "150x150") {
		if (!url || typeof url !== "string") return null;
		if (url.startsWith("https://")) return url.replace("300x300", size);
		return url;
	}
	async function fetchUser(token) {
		const user = (await fetchTwitch(token, "users")).data[0];
		if (!user?.id) throw new Error("Twitch user missing");
		return user;
	}
	async function fetchFollowed(token, userId) {
		const follows = [];
		const seen = /* @__PURE__ */ new Set();
		let cursor;
		do {
			const params = new URLSearchParams({
				user_id: userId,
				first: "100"
			});
			if (cursor) params.set("after", cursor);
			const page = await fetchTwitch(token, "channels/followed", params);
			follows.push(...page.data);
			cursor = page.pagination?.cursor;
			if (cursor && seen.has(cursor)) throw new Error("Repeated Twitch pagination cursor");
			if (cursor) seen.add(cursor);
		} while (cursor);
		return follows;
	}
	async function fetchBatch(token, path, key, ids) {
		const results = [];
		for (let i = 0; i < ids.length; i += 100) {
			const params = new URLSearchParams(path === "streams" ? { first: "100" } : {});
			for (const id of ids.slice(i, i + 100)) params.append(key, id);
			const seen = /* @__PURE__ */ new Set();
			let cursor;
			do {
				if (cursor) params.set("after", cursor);
				const page = await fetchTwitch(token, path, params);
				results.push(...page.data);
				cursor = path === "streams" ? page.pagination?.cursor : null;
				if (cursor && seen.has(cursor)) throw new Error("Repeated Twitch pagination cursor");
				if (cursor) seen.add(cursor);
			} while (cursor);
		}
		return results;
	}
	async function fetchAllFollowed(token) {
		const follows = await fetchFollowed(token, (await fetchUser(token)).id);
		const ids = [...new Set(follows.map((follow) => follow.broadcaster_id))];
		const { map: cachedProfiles, fresh } = await getCachedProfiles();
		const profileMap = fresh ? { ...cachedProfiles } : {};
		const missing = ids.filter((id) => !Object.hasOwn(profileMap, id));
		const profiles = await fetchBatch(token, "users", "id", missing);
		for (const profile of profiles) profileMap[profile.id] = formatAvatarUrl(profile.profile_image_url);
		const streams = await fetchBatch(token, "streams", "user_id", ids);
		const liveMap = new Map(streams.map((stream) => [stream.user_id, stream]));
		const channels = follows.map((follow) => {
			const stream = liveMap.get(follow.broadcaster_id);
			return {
				user_id: follow.broadcaster_id,
				user_login: follow.broadcaster_login,
				user_name: follow.broadcaster_name,
				game_name: null,
				viewer_count: null,
				...stream,
				profile_image_url: formatAvatarUrl(profileMap[follow.broadcaster_id]) ?? null,
				isLive: Boolean(stream)
			};
		});
		return {
			data: {
				live: channels.filter((channel) => channel.isLive).sort((a, b) => b.viewer_count - a.viewer_count),
				offline: channels.filter((channel) => !channel.isLive)
			},
			profileMap,
			profilesChanged: !fresh || missing.length > 0
		};
	}
	//#endregion
	//#region src/oauth.js
	function randomState() {
		return Array.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(32)), (byte) => byte.toString(16).padStart(2, "0")).join("");
	}
	function parseAuthRedirect(redirect, redirectUri, state) {
		if (!redirect) throw new Error("Authentication cancelled");
		const actual = new URL(redirect);
		const expected = new URL(redirectUri);
		if (actual.origin !== expected.origin || actual.pathname !== expected.pathname || actual.searchParams.get("state") !== state) throw new Error("Invalid OAuth redirect or state");
		if (actual.searchParams.has("error")) throw new Error(actual.searchParams.get("error_description") || actual.searchParams.get("error"));
		const code = actual.searchParams.get("code");
		if (!code) throw new Error("No authorization code in redirect");
		return code;
	}
	//#endregion
	//#region src/background.js
	var ALARM_NAME = "twitch_poll_streams";
	var pollTask;
	var authTask;
	var logoutTask;
	var notificationQueue = Promise.resolve();
	var alarmQueue = Promise.resolve();
	var badgeQueue = Promise.resolve();
	function report(error) {
		if (error.code === "SESSION_CHANGED") return;
		console.error("[Twitch Sidebar]", error.message);
	}
	function signOutIfCurrent(error) {
		if (error instanceof AuthError && error.sessionRevision === getSessionRevision()) return signOut();
	}
	function ensureAlarm() {
		const task = alarmQueue.then(async () => {
			const { pollIntervalMinutes } = await getPreferences();
			if ((await callExtension("alarms.get", ALARM_NAME))?.periodInMinutes !== pollIntervalMinutes) await callExtension("alarms.create", ALARM_NAME, { periodInMinutes: pollIntervalMinutes });
		});
		alarmQueue = task.catch(() => {});
		return task;
	}
	function setBadge(count) {
		return callExtension("action.setBadgeText", { text: count > 0 ? String(count) : "" });
	}
	function syncBadgeFromCache() {
		const task = badgeQueue.then(async () => {
			await setBadge((await getCachedChannels())?.data.live.length ?? 0);
		});
		badgeQueue = task.catch(() => {});
		return task;
	}
	function pollStreams() {
		if (pollTask) return pollTask;
		const expected = getSessionRevision();
		pollTask = (async () => {
			const token = await restoreSession();
			assertSession(expected);
			if (!token) return null;
			const { data, profileMap, profilesChanged } = await withSession(fetchAllFollowed);
			assertSession(expected);
			if (profilesChanged) await setCachedProfiles(profileMap);
			assertSession(expected);
			await setCachedChannels(data);
			assertSession(expected);
			await syncBadgeFromCache();
			return data;
		})().finally(() => {
			pollTask = null;
		});
		return pollTask;
	}
	function signOut() {
		if (logoutTask) return logoutTask;
		invalidateSession();
		logoutTask = (async () => {
			await Promise.allSettled([
				pollTask,
				notificationQueue,
				waitForSessionTasks()
			].filter(Boolean));
			await revokeSessionTokens().catch(() => {});
			await clearTokens();
			await clearAllCache();
			await syncBadgeFromCache();
			return { ok: true };
		})().finally(() => {
			logoutTask = null;
		});
		return logoutTask;
	}
	function authenticate() {
		if (authTask) return authTask;
		invalidateSession();
		const expected = getSessionRevision();
		authTask = guardSession(expected, async () => {
			const redirectUri = extension.identity.getRedirectURL();
			const state = randomState();
			const redirect = await callExtension("identity.launchWebAuthFlow", {
				url: `https://id.twitch.tv/oauth2/authorize?${new URLSearchParams({
					client_id: CLIENT_ID,
					redirect_uri: redirectUri,
					response_type: "code",
					scope: SCOPES,
					state,
					force_verify: "false"
				})}`,
				interactive: true
			});
			assertSession(expected);
			const tokens = await requestTokens("exchange", {
				code: parseAuthRedirect(redirect, redirectUri, state),
				redirect_uri: redirectUri,
				code_verifier: state
			});
			assertSession(expected);
			await Promise.allSettled([pollTask, waitForSessionTasks()].filter(Boolean));
			assertSession(expected);
			await clearAllCache();
			await saveTokens(tokens, expected);
			return { authenticated: true };
		}).finally(() => {
			authTask = null;
		});
		return authTask;
	}
	function changeStreamerPreference(key, id, remove = false) {
		if (typeof id !== "string" || !/^\d+$/.test(id)) throw new Error("Invalid broadcaster ID");
		const expected = getSessionRevision();
		const task = notificationQueue.then(async () => {
			const { [key]: stored } = await localGet(key);
			const ids = new Set(Array.isArray(stored) ? stored : []);
			assertSession(expected);
			if (remove || ids.has(id)) ids.delete(id);
			else ids.add(id);
			await localSet({ [key]: [...ids] });
			return { active: ids.has(id) };
		});
		notificationQueue = task.catch(() => {});
		return task;
	}
	async function getProfile() {
		const cached = await getCachedUserProfile();
		if (cached?.fresh) return { profile: cached.profile };
		return withSession(async (token) => {
			try {
				const profile = await fetchUser(token);
				try {
					profile.followers = (await fetchTwitch(token, "channels/followers", new URLSearchParams({
						broadcaster_id: profile.id,
						first: "1"
					}))).total;
				} catch (error) {
					if (error instanceof AuthError) throw error;
				}
				await setCachedUserProfile(profile);
				return { profile };
			} catch (error) {
				if (cached?.profile && !(error instanceof AuthError)) return { profile: cached.profile };
				throw error;
			}
		});
	}
	/** @param {import("./types.js").ExtensionMessage} message */
	async function route(message) {
		if (message.type === "SESSION_LOGOUT") return signOut();
		if (logoutTask) await logoutTask;
		switch (message.type) {
			case "TWITCH_AUTH": return authenticate();
			case "TWITCH_GET_REDIRECT_URL": return { redirectUrl: extension.identity.getRedirectURL() };
			case "SESSION_RESTORE": return { authenticated: Boolean(await restoreSession()) };
			case "GET_PROFILE": return getProfile();
			case "LOAD_CHANNELS":
			case "POLL_NOW": {
				await ensureAlarm();
				const channels = await pollStreams();
				const cached = await getCachedChannels();
				return {
					channels: cached?.data ?? channels,
					updatedAt: cached?.ts ?? 0
				};
			}
			case "SET_POLL_INTERVAL":
				if (!POLL_INTERVAL_OPTIONS.includes(message.minutes)) throw new Error("Invalid refresh interval");
				await localSet({ [POLL_INTERVAL_KEY]: message.minutes });
				await ensureAlarm();
				return { pollIntervalMinutes: (await getPreferences()).pollIntervalMinutes };
			case "SET_FAVORITES_FIRST":
				if (typeof message.enabled !== "boolean") throw new Error("Invalid favorite sorting preference");
				await localSet({ [FAVORITES_FIRST_KEY]: message.enabled });
				return { favoritesFirst: message.enabled };
			case "SET_REMEMBER_SESSION":
				if (typeof message.enabled !== "boolean") throw new Error("Invalid session persistence preference");
				return setRememberSession(message.enabled);
			case "TOGGLE_FAVORITE":
			case "TOGGLE_NOTIFICATION": return changeStreamerPreference(NOTIFICATIONS_KEY, message.broadcasterId);
			case "REMOVE_FAVORITE":
			case "REMOVE_NOTIFICATION": return changeStreamerPreference(NOTIFICATIONS_KEY, message.broadcasterId, true);
			default: return { error: "Unknown message" };
		}
	}
	extension.runtime.onMessage.addListener((message, sender, respond) => {
		if (sender.id !== extension.runtime.id || !message || typeof message.type !== "string") return false;
		route(message).then(respond).catch(async (error) => {
			await signOutIfCurrent(error)?.catch(report);
			respond({
				error: error.message,
				code: error instanceof AuthError ? "AUTH_REQUIRED" : error.code
			});
		});
		return true;
	});
	extension.action.onClicked.addListener((tab) => {
		(isFirefox ? callExtension("sidebarAction.toggle") : callExtension("sidePanel.open", { windowId: tab.windowId })).catch(report);
	});
	function runPoll() {
		if (logoutTask) return;
		return pollStreams().catch(async (error) => {
			await signOutIfCurrent(error)?.catch(report);
			if (!(error instanceof AuthError)) report(error);
		});
	}
	extension.storage.onChanged.addListener((changes, area) => {
		if (area !== "local") return;
		if (changes["pollIntervalMinutes"]) ensureAlarm().catch(report);
		if (changes["twitch_channels_cache"]) syncBadgeFromCache().catch(report);
	});
	extension.runtime.onInstalled.addListener(() => {
		if (!isFirefox && extension.sidePanel?.setPanelBehavior) callExtension("sidePanel.setPanelBehavior", { openPanelOnActionClick: true }).catch(report);
		ensureAlarm().catch(report);
		runPoll();
	});
	extension.runtime.onStartup.addListener(() => {
		ensureAlarm().catch(report);
		runPoll();
	});
	extension.alarms.onAlarm.addListener((alarm) => {
		if (alarm.name === ALARM_NAME) return runPoll();
	});
	if (!isFirefox && extension.sidePanel?.setPanelBehavior) callExtension("sidePanel.setPanelBehavior", { openPanelOnActionClick: true }).catch(report);
	callExtension("action.setBadgeBackgroundColor", { color: "#9147ff" }).catch(report);
	ensureAlarm().catch(report);
	syncBadgeFromCache().catch(report);
	//#endregion
})();
